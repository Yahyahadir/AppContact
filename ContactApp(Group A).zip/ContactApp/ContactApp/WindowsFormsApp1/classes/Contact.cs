﻿// Contact class
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace WindowsFormsApp1.classes
{
    class Contact
    {
        public int contactId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string contactPhone { get; set; }
        public string adress { get; set; }
        public string gender { get; set; }

        static string connstring = ConfigurationManager.ConnectionStrings["connxstring"].ConnectionString;

        public DataTable ListContact()
        {
            SqlConnection sqlConnection = new SqlConnection(connstring);
            sqlConnection.Open();
            DataTable dt = new DataTable();

            string requette = "SELECT * FROM contacts";

            try
            {
                SqlCommand cmd = new SqlCommand(requette, sqlConnection);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                sqlConnection.Close();
            }
            return dt;
        }

        public bool Insert(Contact c)
        {
            bool isInsert = false;
            SqlConnection sqlConnection = new SqlConnection(connstring);
            sqlConnection.Open();
            try
            {
                string requette = "INSERT INTO contacts (firstName,lastName,contactPhone,adress,gender) VALUES (@firstName,@lastName,@contactPhone,@adress,@gender)";
                SqlCommand cmd = new SqlCommand(requette, sqlConnection);
                cmd.Parameters.AddWithValue("@firstName", c.firstName);
                cmd.Parameters.AddWithValue("@lastName", c.lastName);
                cmd.Parameters.AddWithValue("@adress", c.adress);
                cmd.Parameters.AddWithValue("@contactPhone", c.contactPhone);
                cmd.Parameters.AddWithValue("@gender", c.gender);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    isInsert = true;
                }
                else
                {
                    isInsert = false;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                sqlConnection.Close();
            }

            return isInsert;
        }

        public bool Update(Contact c)
        {
            bool isUpdate = false;
            SqlConnection sqlConnection = new SqlConnection(connstring);
            sqlConnection.Open();
            try
            {
                string requette = "UPDATE contacts SET firstName = @firstName, lastName = @lastName, " +
                                   "contactPhone = @contactPhone, adress = @adress, gender = @gender " +
                                   "WHERE contactId = @contactId";
                SqlCommand cmd = new SqlCommand(requette, sqlConnection);
                cmd.Parameters.AddWithValue("@firstName", c.firstName);
                cmd.Parameters.AddWithValue("@lastName", c.lastName);
                cmd.Parameters.AddWithValue("@adress", c.adress);
                cmd.Parameters.AddWithValue("@contactPhone", c.contactPhone);
                cmd.Parameters.AddWithValue("@gender", c.gender);
                cmd.Parameters.AddWithValue("@contactId", c.contactId);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    isUpdate = true;
                }
                else
                {
                    isUpdate = false;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                sqlConnection.Close();
            }

            return isUpdate;
        }

        public bool Delete(int contactId)
        {
            bool isDelete = false;
            SqlConnection sqlConnection = new SqlConnection(connstring);
            sqlConnection.Open();
            try
            {
                string requette = "DELETE FROM contacts WHERE contactId = @contactId";
                SqlCommand cmd = new SqlCommand(requette, sqlConnection);
                cmd.Parameters.AddWithValue("@contactId", contactId);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    isDelete = true;
                }
                else
                {
                    isDelete = false;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                sqlConnection.Close();
            }

            return isDelete;
        }

        public void RefreshTable(DataGridView dataGridView)
        {
            DataTable dt = ListContact();
            dataGridView.DataSource = dt;
        }
    }
}
