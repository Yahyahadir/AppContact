﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtContactId = new System.Windows.Forms.TextBox();
            this.txtfirstName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAdress = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.AddBt = new System.Windows.Forms.Button();
            this.UpdateBt = new System.Windows.Forms.Button();
            this.DeleteBt = new System.Windows.Forms.Button();
            this.CleanBt = new System.Windows.Forms.Button();
            this.dtContact = new System.Windows.Forms.DataGridView();
            this.Search = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtGender = new System.Windows.Forms.ComboBox();
            this.txtContactPhone = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtContact)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Contact ID";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtContactId
            // 
            this.txtContactId.Location = new System.Drawing.Point(162, 110);
            this.txtContactId.Name = "txtContactId";
            this.txtContactId.Size = new System.Drawing.Size(174, 22);
            this.txtContactId.TabIndex = 1;
            this.txtContactId.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtfirstName
            // 
            this.txtfirstName.Location = new System.Drawing.Point(162, 155);
            this.txtfirstName.Name = "txtfirstName";
            this.txtfirstName.Size = new System.Drawing.Size(174, 22);
            this.txtfirstName.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(46, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "First Name";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtAdress
            // 
            this.txtAdress.Location = new System.Drawing.Point(162, 247);
            this.txtAdress.Name = "txtAdress";
            this.txtAdress.Size = new System.Drawing.Size(174, 22);
            this.txtAdress.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(46, 247);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Adress";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(162, 202);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(174, 22);
            this.txtLastName.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(46, 202);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Last Name";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(46, 297);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Gendre";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // AddBt
            // 
            this.AddBt.BackColor = System.Drawing.Color.Lime;
            this.AddBt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddBt.Location = new System.Drawing.Point(50, 413);
            this.AddBt.Name = "AddBt";
            this.AddBt.Size = new System.Drawing.Size(95, 41);
            this.AddBt.TabIndex = 10;
            this.AddBt.Text = "ADD";
            this.AddBt.UseVisualStyleBackColor = false;
            this.AddBt.Click += new System.EventHandler(this.AddBt_Click);
            // 
            // UpdateBt
            // 
            this.UpdateBt.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.UpdateBt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UpdateBt.Location = new System.Drawing.Point(162, 413);
            this.UpdateBt.Name = "UpdateBt";
            this.UpdateBt.Size = new System.Drawing.Size(95, 41);
            this.UpdateBt.TabIndex = 11;
            this.UpdateBt.Text = "UPDATE";
            this.UpdateBt.UseVisualStyleBackColor = false;
            this.UpdateBt.Click += new System.EventHandler(this.UpdateBt_Click);
            // 
            // DeleteBt
            // 
            this.DeleteBt.BackColor = System.Drawing.Color.Red;
            this.DeleteBt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DeleteBt.Location = new System.Drawing.Point(275, 413);
            this.DeleteBt.Name = "DeleteBt";
            this.DeleteBt.Size = new System.Drawing.Size(95, 41);
            this.DeleteBt.TabIndex = 12;
            this.DeleteBt.Text = "DELETE";
            this.DeleteBt.UseVisualStyleBackColor = false;
            this.DeleteBt.Click += new System.EventHandler(this.DeleteBt_Click);
            // 
            // CleanBt
            // 
            this.CleanBt.BackColor = System.Drawing.Color.Yellow;
            this.CleanBt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CleanBt.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.CleanBt.FlatAppearance.BorderSize = 0;
            this.CleanBt.Location = new System.Drawing.Point(389, 413);
            this.CleanBt.Name = "CleanBt";
            this.CleanBt.Size = new System.Drawing.Size(95, 41);
            this.CleanBt.TabIndex = 13;
            this.CleanBt.Text = "CLEAN";
            this.CleanBt.UseVisualStyleBackColor = false;
            this.CleanBt.Click += new System.EventHandler(this.button4_Click);
            // 
            // dtContact
            // 
            this.dtContact.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtContact.Location = new System.Drawing.Point(448, 110);
            this.dtContact.Name = "dtContact";
            this.dtContact.RowHeadersWidth = 51;
            this.dtContact.RowTemplate.Height = 24;
            this.dtContact.Size = new System.Drawing.Size(361, 207);
            this.dtContact.TabIndex = 14;
            this.dtContact.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtContact_CellContentClick);
            // 
            // Search
            // 
            this.Search.Location = new System.Drawing.Point(528, 71);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(250, 22);
            this.Search.TabIndex = 16;
            this.Search.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(444, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 20);
            this.label6.TabIndex = 15;
            this.label6.Text = "Search";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // txtGender
            // 
            this.txtGender.FormattingEnabled = true;
            this.txtGender.Items.AddRange(new object[] {
            "Men",
            "Women"});
            this.txtGender.Location = new System.Drawing.Point(162, 293);
            this.txtGender.Name = "txtGender";
            this.txtGender.Size = new System.Drawing.Size(174, 24);
            this.txtGender.TabIndex = 18;
            this.txtGender.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // txtContactPhone
            // 
            this.txtContactPhone.Location = new System.Drawing.Point(165, 340);
            this.txtContactPhone.Name = "txtContactPhone";
            this.txtContactPhone.Size = new System.Drawing.Size(174, 22);
            this.txtContactPhone.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(49, 340);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 20);
            this.label7.TabIndex = 19;
            this.label7.Text = "contact Phone";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(866, 486);
            this.Controls.Add(this.txtContactPhone);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtGender);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dtContact);
            this.Controls.Add(this.CleanBt);
            this.Controls.Add(this.DeleteBt);
            this.Controls.Add(this.UpdateBt);
            this.Controls.Add(this.AddBt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtAdress);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtfirstName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtContactId);
            this.Controls.Add(this.label1);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtContact)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtContactId;
        private System.Windows.Forms.TextBox txtfirstName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAdress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button AddBt;
        private System.Windows.Forms.Button UpdateBt;
        private System.Windows.Forms.Button DeleteBt;
        private System.Windows.Forms.Button CleanBt;
        private System.Windows.Forms.DataGridView dtContact;
        private System.Windows.Forms.TextBox Search;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox txtGender;
        private System.Windows.Forms.TextBox txtContactPhone;
        private System.Windows.Forms.Label label7;
    }
}

