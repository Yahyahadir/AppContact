﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.classes;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }



        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void button4_Click(object sender, EventArgs e)
        {
            CleanFields();
        }
        private void AddBt_Click(object sender, EventArgs e)
        {
            Contact c = new Contact();

            c.lastName = txtLastName.Text;
            c.firstName = txtfirstName.Text;
            c.gender = txtGender.Text;
            c.adress = txtAdress.Text;
            c.contactPhone = txtContactPhone.Text;

            c.Insert(c);

            DataTable dt = c.ListContact();
            dtContact.DataSource = dt;
            

        }

        private void UpdateBt_Click(object sender, EventArgs e)
        {
            Contact c = new Contact();

            c.contactId = int.Parse(txtContactId.Text); 
            c.lastName = txtLastName.Text;
            c.firstName = txtfirstName.Text;
            c.gender = txtGender.Text;
            c.adress = txtAdress.Text;
            c.contactPhone = txtContactPhone.Text;

            c.Update(c);

            DataTable dt = c.ListContact();
            dtContact.DataSource = dt;
        }

        private void DeleteBt_Click(object sender, EventArgs e)
        {
            Contact c = new Contact();
            if (int.TryParse(txtContactId.Text, out int contactId))
            {
            }
            else
            {
                MessageBox.Show("Invalid Contact ID. Please enter a valid integer.");
            }

            c.Delete(contactId);

            DataTable dt = c.ListContact();
            dtContact.DataSource = dt;
        }

        private void CleanFields()
        {
            txtContactId.Text = "";
            txtfirstName.Text = "";
            txtLastName.Text = "";
            txtAdress.Text = "";
            txtContactPhone.Text = "";
            txtGender.Text = "";
        }

        private void dtContact_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Contact c = new Contact();
            c.RefreshTable(dtContact);

        }
    }
}
